<?php
    session_start();
    include "db_conn.php";
    mysqli_report(MYSQLI_REPORT_STRICT);
    
        function ClassAvailability($classID,$conn){
            $sql = "SELECT MaxStudents - abs(CurrentStudents) as AvailableSpots FROM classes WHERE id = $classID";
            $availableSpace = mysqli_query($conn, $sql);      
            $row = $availableSpace->fetch_assoc();
            $availableSpace = $row['AvailableSpots'];
            return $availableSpace;
         }

         function CheckWaitlistPosition($classID,$studentID,$conn){
            $sql = "SELECT position FROM waitlist WHERE classID = $classID AND studentID = $studentID";
            $result = mysqli_query($conn, $sql) or die(mysqli_error());      
            $row = $result->fetch_assoc();
            $result = $row['position'];
            return $result;
         }

        function WithdrawFromClass($classID, $studentID, $conn){
            $sql =  "DELETE FROM registrations where studentID = $studentID and classID = $classID";
            
             $result = mysqli_query($conn, $sql) or die(mysqli_error());      
             UpadteAvailability($classID, -1,$conn);
             AddFromWaitlist($classID, $studentID,$conn);
             header ("Location: classes.php?error=$sql");
        }

        function AddFromWaitlist($classID, $studentID, $conn){
            $sql = "SELECT studentID 
            from waitlist 
            WHERE classID = $classID 
            order by position desc
            limit 1";
            $result = mysqli_query($conn, $sql) or die(mysqli_error());   
            $row = $result->fetch_assoc();
            $result = $row['studentID'];   
            if (is_null($result)){
                exit();
            }else{
                RegisterForAClass($classID, $result, $conn);    
                WithdrawFromWaitlist($classID, $result, $conn);
            }
            

        }

        function WithdrawFromWaitlist($classID,$studentID,$conn){
            $currentPosition = CheckWaitlistPosition($classID, $studentID, $conn);
            $sql = "DELETE FROM waitlist WHERE classID = $classID AND studentID = $studentID";
            $result = mysqli_query($conn, $sql) or die(mysqli_error());
            UpdateWaitlist($classID,$currentPosition,$conn);
            header ("Location: classes.php?error=Removed from waitlist.");
        }

        function UpdateWaitlist($classID,$position,$conn){
            $sql = "UPDATE waitlist SET position = position-1 WHERE classID = $classID AND position > $position";
            $result = mysqli_query($conn, $sql) or die(mysqli_error());      
        }

        function UpadteAvailability($classID, $spot,$conn){
            if ($spot > 0) {
                $sql = "UPDATE classes Set CurrentStudents = CurrentStudents + $spot where id = $classID;";
                $result = mysqli_query($conn, $sql) or die(mysqli_error());      
            }else{
                $sql = "UPDATE classes Set CurrentStudents = CurrentStudents - abs($spot) where id = $classID;";
                $result = mysqli_query($conn, $sql) or die(mysqli_error());      
            }
            
        }

        function RegisterForAClass($classID, $studentID,$conn){
            if (ClassAvailability($classID,$conn) > 0){
                $sql = "INSERT INTO registrations VALUES ($studentID, $classID);";
                $result = mysqli_query($conn, $sql) or die(mysqli_error());      
                
                UpadteAvailability($classID, 1,$conn);
                header ("Location: classes.php?error=Registered.");
            }else{
                AddToWaitlist($classID, $studentID,$conn);
                header ("Location: classes.php?error=Added to waitlist.");
            }
        }

        function AddToWaitlist($classID, $studentID,$conn){
            $sql = "SELECT MAX(position)+1 as Position from waitlist WHERE classID = $classID";
            $position = mysqli_query($conn, $sql);  
            $row = $position->fetch_assoc();
            $position = $row['Position'];      
            if(is_null($position)){
               $position = 1;     
            }
                $sql = "INSERT INTO waitlist VALUES ($classID, $studentID, $position)";
                $result = mysqli_query($conn, $sql); 
            


        }

        $classID = $_REQUEST['id'] ?? null;
        $studentID = $_REQUEST['studentID'] ?? null;
        

        if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['Register']))
        {
            RegisterForAClass($classID, $studentID,$conn);
        }
        if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['Withdraw']))
        {
            WithdrawFromClass($classID, $studentID, $conn);
        }
        if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['WithdrawWaitlist']))
        {
            WithdrawFromWaitlist($classID, $studentID,$conn);
        }
        

        exit();
        ?>
        
