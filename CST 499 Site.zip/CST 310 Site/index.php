<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!doctype html>
<html lang ="en">

    <head>
        <title> Employee Portal </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.mis.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        

    </head>
    <body>
<?php require 'master.php';?>       
       <div class='container text-center'>
       <h1>Welcome to the Employee Portal!</h1>
       </div>
       <div class='container text-center'>

</div>
       
       
<?php require_once 'footer.php';?>       
    </body>
</html>
