<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!doctype html>
<html lang ="en">

    <head>
        <title> Login Page </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.mis.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        

    </head>
    <body>
<?php require 'master.php';?>       
       <div class='container text-center'>
       <h1>Welcome to the Login Page!</h1>
       <form action="verifyLogin.php" method="post">
       <?php if(isset($_GET['error' ])) { ?>
            <p class="error"> <?php echo $_GET['error']; ?></p>
        <?php } ?>

       </div>
            <p>
                            <label for="emailAddress">Email Address:</label>
                            <input type="text" name="email">
                         </p>             
            <p>
                            <label for="password">Password:</label>
                            <input type="text" name="password">
                         </p>                         


                         <button type="submit"> Login </button>
       </form>

</div>
    


<?php require_once 'footer.php';?>       
    </body>
</html>
