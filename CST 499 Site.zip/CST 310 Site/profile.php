<?php

session_start();

if(isset($_SESSION['s_first_name'])){
    ?>
    <!doctype html>
    <html lang ="en">

        <head>
            <title> Profile Page </title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.mis.js"></script>
            <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
            

        </head>
        <body>
            
    <?php require 'master.php';?>       
        <div class='container text-center'>
        <h1>Welcome to the Profile Page, <?php echo $_SESSION['s_first_name']?><?php echo $_SESSION['s_studentID']?>!</h1>
        </div>
        <p>
                            <label >Email Address: <?php echo $_SESSION['s_email']?></label>
        </p>             
        <p>
                            <label >Password: <?php echo $_SESSION['s_password']?></label>
        </p> 
        <p>
                            <label >First Name: <?php echo $_SESSION['s_first_name']?></label>
        </p> 
        <p>
                            <label >Last Name: <?php echo $_SESSION['s_last_name']?></label>
        </p> 
        <p>
                            <label >Address: <?php echo $_SESSION['s_address']?></label>
        </p> 
        <p>
                            <label >Phone Number: <?php echo $_SESSION['s_phone']?></label>
        </p> 
        <p>
                            <label >Salary: <?php echo $_SESSION['s_salary']?></label>
        </p> 
        <p>
                            <label >SSN: <?php echo $_SESSION['s_SSN']?></label>
        </p> 
        
        
        
    <?php require_once 'footer.php';?>       
        </body>
    </html>
    <?php
}
else {
    header("Location: login.php");
    exit();

}
?>
