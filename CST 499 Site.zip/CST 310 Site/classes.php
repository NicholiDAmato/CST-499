<?php
session_start();
include "db_conn.php";

if(isset($_SESSION['s_first_name'])){
   ?>
   <!doctype html>
   <html lang ="en">

       <head>
           <title> Class Registration</title>
           <meta charset="utf-8">
           <meta name="viewport" content="width=device-width, initial-scale=1">
           <link rel="stylesheet" href="css/bootstrap.min.css">
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.mis.js"></script>
           <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        </head>
       <body>
      
<?php require 'master.php';?>       
       <div class='container text-center'>
       <h1>Please Register Below!</h1>

         <?php 
                    
               $studentID = $_SESSION['s_studentID'];
               $sql = "SELECT * FROM classes INNER JOIN registrations on classID = id where studentID ='$studentID'";  
               $enrolledClasses = mysqli_query($conn, $sql);   
               $sql = "SELECT * FROM classes INNER JOIN waitlist on classID = id where studentID ='$studentID'";  
               $waitlistClasses = mysqli_query($conn, $sql);   
               if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['Spring']))
               {
                $sql = "SELECT id, max(name) Name, max(MaxStudents) MaxStudents, max(CurrentStudents) CurrentStudents, max(Semester) Semester FROM classes c 
                            LEFT JOIN 
                            (SELECT classID, studentID FROM classes INNER JOIN registrations on classID = id where studentID =$studentID) r on r.classID = c.id
                               LEFT JOIN 
                            (SELECT classID, studentID FROM classes INNER JOIN waitlist on classID = id where studentID =$studentID) w on w.classID = c.id
                         WHERE isNULL(r.studentID) and isNULL(w.studentID) and Semester = 'Spring'
                         GROUP BY id"
          ;
          $openClasses = mysqli_query($conn, $sql); 
               }elseif($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['Summer']))
               {
                $sql = "SELECT id, max(name) Name, max(MaxStudents) MaxStudents, max(CurrentStudents) CurrentStudents, max(Semester) Semester FROM classes c 
                            LEFT JOIN 
                            (SELECT classID, studentID FROM classes INNER JOIN registrations on classID = id where studentID =$studentID) r on r.classID = c.id
                               LEFT JOIN 
                            (SELECT classID, studentID FROM classes INNER JOIN waitlist on classID = id where studentID =$studentID) w on w.classID = c.id
                         WHERE isNULL(r.studentID) and isNULL(w.studentID) and Semester = 'Summer'
                         GROUP BY id"
          ;
          $openClasses = mysqli_query($conn, $sql); 
               }
               else{
                $sql = "SELECT id, max(name) Name, max(MaxStudents) MaxStudents, max(CurrentStudents) CurrentStudents, max(Semester) Semester FROM classes c 
                         LEFT JOIN 
                         (SELECT classID, studentID FROM classes INNER JOIN registrations on classID = id where studentID =$studentID) r on r.classID = c.id
                            LEFT JOIN 
                         (SELECT classID, studentID FROM classes INNER JOIN waitlist on classID = id where studentID =$studentID) w on w.classID = c.id
                         WHERE isNULL(r.studentID) and isNULL(w.studentID)
                         GROUP BY id"
          ;
          $openClasses = mysqli_query($conn, $sql); 
               }
?>
               
               <h2>Registered Classes:</h2>
<?php

                  while($row = $enrolledClasses->fetch_assoc()) {
                     ?><form method="post" action="registerForAClass.php"><?php
                     echo "  Class: " . $row["Name"]. " Semester: " . $row["Semester"].  "  Slots: " . $row["MaxStudents"]-$row["CurrentStudents"] 
                     ?>
                     <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
                     <input type="hidden" name="studentID" value="<?php echo $studentID; ?>"/>
                     <input type="submit" class="button" name="Withdraw" value="Withdraw" /> <?php
                         echo "<br>";
                         ?></form><?php
                     }
                     ?>
                  
                  <h2>Waitlist Classes:</h2>
<?php
                  while($row = $waitlistClasses->fetch_assoc()) {
                     ?><form method="post" action="registerForAClass.php"><?php
                     echo "  Class: " . $row["Name"]. " Semester: " . $row["Semester"].  "  Position: " . $row["position"] 
                     ?>
                     <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
                     <input type="hidden" name="studentID" value="<?php echo $studentID; ?>"/>
                     <input type="submit" class="button" name="WithdrawWaitlist" value="Withdraw" /> <?php
                         echo "<br>";
                         ?></form><?php
                     }
                     ?>
                  </div>   
                  <div class='container text-center'>
               <h2>Available Classes:</h2>
               <div class='container text-center'>
               
               <form method="post" action="classes.php">
               <div>
               <input type="submit" class = 'button' name="All" value="All"/> 
               <input type="submit" class = 'button' name="Spring" value="Spring"/> 
               <input type="submit" class = 'button' name="Summer" value="Summer"/> 
               <br>
               <br>
               </div>   

</div>
                  <?php
                     while($row = $openClasses->fetch_assoc()) {
                        ?><form method="post" action="registerForAClass.php"><?php
                        echo " Class: " . $row["Name"]. " Semester: " . $row["Semester"].  "  Slots: " . $row["MaxStudents"]-$row["CurrentStudents"] 
                        ?>
                        <input type="hidden" name="studentID" value="<?php echo $studentID; ?>"/>
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
                        <input type="submit" class = 'button' name="Register" value="Register" "; /> <?php
                            echo "<br>";
                            ?></form><?php

                    }

                ?>
    
</div>
<?php require_once 'footer.php';?>       
    </body>
</html>
<?php
}

else {
    header("Location: login.php");
    exit();

}


?>