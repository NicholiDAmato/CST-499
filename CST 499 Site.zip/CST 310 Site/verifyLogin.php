<?php
session_start();
include "db_conn.php";

if(isset($_POST['email']) && isset($_POST['password'])) {
    
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;

    }
}

$email = validate($_POST['email']);
$password = validate($_POST['password']);


if(empty($email)) {
    header ("Location: login.php?error=Email is required.");
    exit();
}
if(empty($password)) {
    header ("Location: login.php?error=Password is required.");
    exit();
}

$sql = "SELECT * FROM students where email='$email' AND password='$password'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) === 1) {
    $row = mysqli_fetch_assoc($result);
    if($row['email'] === $email && $row['password'] === $password){
        echo "Logged in.";
        $_SESSION['s_studentID'] = $row['id'];
        $_SESSION['s_email'] = $row['email'];
        $_SESSION['s_password'] = $row['password'];
        $_SESSION['s_first_name'] = $row['firstName'];
        $_SESSION['s_last_name'] = $row['lastName'];
        $_SESSION['s_address'] = $row['address'];
        $_SESSION['s_phone'] = $row['phone'];
        $_SESSION['s_salary'] = $row['salary'];
        $_SESSION['s_SSN'] = $row['SSN'];
        header("Location: profile.php");
        exit();
    }
    else {
        header ("Location: login.php?error=Invalid Login.");
    }
}
else {
    header ("Location: login.php?error=Failed Validation.");
    exit();
}