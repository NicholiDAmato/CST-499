<!DOCTYPE html>
<html>
 
<head>
    <title>Insert Page page</title>
</head>
 
<body>
    <center>
        <?php
        include "db_conn.php";
        // servername => localhost
        // username => root
        // password => empty
        // database name => "cst310website"
        //$conn = mysqli_connect("localhost", "root", "", "cst310website");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // Taking all 7 values from the form data(input)
        $email = $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $firstName =  $_REQUEST['firstName'];
        $lastName = $_REQUEST['lastName'];
        $address = $_REQUEST['address'];
        $phone = $_REQUEST['phone'];
        $SSN = $_REQUEST['SSN'];
        
         
        // Performing insert query execution
        // here our table name is students
        $sql = "INSERT INTO students VALUES (0,'$email','$password','$firstName','$lastName','$address','$phone','$SSN')";
         
        if(mysqli_query($conn, $sql)){
                header ("Location: registration.php?error=Data stored in a database successfully.");
                exit();
        } else{
            header ("Location: registration.php?error=Failed to store data.");
            exit();
        }
         
        // Close connection
        mysqli_close($conn);
        
    exit();
        ?>
        
    </center>
</body>
 
</html>