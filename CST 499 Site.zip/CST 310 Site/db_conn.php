<?php

// servername => localhost
        // $username => root
        // $password => empty
        // $database_name => "cst310website"
        
        $conn = mysqli_connect("localhost", "root", "", "cst310website");
         
        // Check connection
        if(!$conn){
            echo "ERROR: Could not connect. ";
        }


?>