<?php
error_reporting(E_ALL ^ E_NOTICE)

?>
<!doctype html>
<html lang ="en">


    <head>
        <title> Registration Page </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.mis.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        

    </head>
    <body>
<?php require 'master.php';?>       
       <div class='container text-center'>
       <h1>Please Register Below!</h1>
       <?php if(isset($_GET['error' ])) { ?>
            <p class="error"> <?php echo $_GET['error']; ?></p>
            <?php } ?>
       </div>
       <div class="text-center">
       <form action="insert.php" method="post">
            <p>
                            <label for="emailAddress">Email Address:</label>
                            <input type="text" name="email" id="emailAddress">
                         </p>             
            <p>
                            <label for="password">Password:</label>
                            <input type="text" name="password" id="password">
                         </p>                         
             <p>
                            <label for="firstName">First Name:</label>
                            <input type="text" name="firstName" id="firstName">
                         </p>
            <p>
                            <label for="lastName">Last Name:</label>
                            <input type="text" name="lastName" id="lastName">
                         </p>
            <p>
                            <label for="Address:">Address:</label>
                            <input type="text" name="address" id="address">
                         </p>
            <p>
                            <label for="phone">Phone:</label>
                            <input type="text" name="phone" id="phone">
                         </p>                           
            <p>
                            <label for="SSN">SSN:</label>
                            <input type="text" name="SSN" id="SSN">
                         </p>                                

                         <input type="submit" value="Submit">
                      </form>
</div>
       
<?php require_once 'footer.php';?>       
    </body>
</html>
