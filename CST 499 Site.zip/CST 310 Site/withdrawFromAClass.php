<?php 
session_start();
include "db_conn.php";

?>


<!DOCTYPE html>
<html>
 
<head>
    <title>Insert Page page</title>
</head>
 
<body>
    <center>
        <?php
        

        // servername => localhost
        // username => root
        // password => empty
        // database name => "cst310website"
        //$conn = mysqli_connect("localhost", "root", "", "cst310website");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         

        $studentID = $_POST['studentID'];
        $classID = $_POST['id'];
         

    



        // Withdraw from the class

        function WithdrawFromClass($classID,$studentID){
               // Get class status
                $sql = "DELETE registrations WHERE id = $classID AND studentID = $studentID";
                AddFromWhitelist($classID, $studentID);
        }

        function AddFromWhitelist($classID, $studentID){
            $sql = "SELECT MIN(position) as Position from waitlist WHERE id = $classID";

        }

             

  

            
        }else{
            //Update waitlist
            $sql = "SELECT MAX(position) as Position from waitlist WHERE id = $classID";
            $nextWaitlistSpot = mysqli_query($conn, $sql);       
            $row = $availableSpace->fetch_assoc();
            $nextWaitlistSpot = $row['Position']; 
            $sql = "INSERT INTO waitlist VALUES ($classID, $stuentID, $nextWaitlistSpot)";
            
        }
        
        



        if(mysqli_query($conn, $sql)){
                header ("Location: classes.php?error=Data stored in a database successfully.");
                exit();
        } else{
            header ("Location: classes.php?error=Failed to store data.");
            exit();
        }
         
        // Close connection
        mysqli_close($conn);
        
    exit();
        ?>
        
    </center>
</body>
 
</html>